# See https://developer.twitter.com/en/apps
CONSUMER_KEY="replace_with_consumer_key"
CONSUMER_SECRET="replace_with_consumer_secret"